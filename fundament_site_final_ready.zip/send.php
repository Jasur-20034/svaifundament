<?php
$token = "8092065456:AAGzZj2YHYjIwFzP969XsWMigSuTHSinfn4";
$chat_id = "6854182458";

$name = $_POST['name'];
$phone = $_POST['phone'];
$comment = $_POST['comment'];
$diameter = $_POST['diameter'];
$length = $_POST['length'];

$message = "📩 Новая заявка с сайта:%0A";
$message .= "👤 Имя: " . $name . "%0A";
$message .= "📞 Телефон: " . $phone . "%0A";
$message .= "📏 Свая: " . $diameter . " мм x " . $length . " мм%0A";
$message .= "💬 Комментарий: " . $comment;

$url = "https://api.telegram.org/bot{$token}/sendMessage?chat_id={$chat_id}&text=" . urlencode($message);

file_get_contents($url);
header("Location: index.html");
?>